package com.meuvt.model;

public class Usuario {

    private Long id;
    private String nome;
    private String telefone;
    private String email;
    private String genero;
    private String login;
    private String senha;
    private boolean admin;

    public Usuario() {
    }

    /**
     * @param login
     * @param senha
     */
    public Usuario(String login, String senha) {
        this.id = 1L;
        this.nome = "Willian";
        this.telefone = "(51)3366-9090";
        this.email = "admin@meuvt.com.br";
        this.genero = "Masculino";
        this.login = login;
        this.senha = senha;
        this.admin = true;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    /**
     * 
     * @return o sim para perfil administrtivo e o não para perfil de usuário comum
     */
    public String getAdminString() {
        if (admin) {
            return "SIM";
        } else {
            return "NAO";
        }
    }

    public boolean validaLogin(String login, String senha) {
        return (this.login.equals(login) && this.senha.equals(senha));
    }
}
