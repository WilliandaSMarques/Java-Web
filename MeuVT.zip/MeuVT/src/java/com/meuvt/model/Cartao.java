package com.meuvt.model;

public class Cartao {

    private Long id;
    private String titular;
    private String tipoCartao;
    private String anoValidade;

    public Cartao() {
    }

    /**
     *
     * @param id
     */
    public Cartao(Long id) {
        this.id = id;
        this.titular = "Willian";
        this.tipoCartao = "MEUVT";
        this.anoValidade = "2020";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getTipoCartao() {
        return tipoCartao;
    }

    public void setTipoCartao(String tipoCartao) {
        this.tipoCartao = tipoCartao;
    }

    public String getAnoValidade() {
        return anoValidade;
    }

    public void setAnoValidade(String anoValidade) {
        this.anoValidade = anoValidade;
    }
}