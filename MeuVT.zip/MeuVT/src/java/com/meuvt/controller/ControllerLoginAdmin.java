/*
 * Classe responsável por realizar o controle(filtro) de login administrativo
 */
package com.meuvt.controller;

import com.meuvt.view.LoginMB;
import java.io.IOException;
import javax.inject.Inject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Willian
 */
@WebFilter(filterName = "ControllerLoginAdministrativo", urlPatterns = {"/faces/paginas/admin/*"})
public class ControllerLoginAdmin implements Filter {

    @Inject
    LoginMB loginMB;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        if (loginMB != null && loginMB.isLogado() && loginMB.perfilAdmin()) {
            chain.doFilter(request, response);
        } else {
            res.sendRedirect(req.getContextPath() + "faces/paginas/login.xhtml");
        }
    }

    @Override
    public void destroy() {

    }

}
