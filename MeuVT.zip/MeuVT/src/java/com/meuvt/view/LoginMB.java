package com.meuvt.view;

import com.meuvt.model.Usuario;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value = "LoginMB")
@SessionScoped
public class LoginMB implements Serializable {

    @Inject
    UsuarioMB usuarioMB;

    private String login;
    private String senha;
    private Usuario usuarioDaSessao;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Usuario getUsuarioDaSessao() {
        return usuarioDaSessao;
    }

    public void setUsuarioDaSessao(Usuario usuarioDaSessao) {
        this.usuarioDaSessao = usuarioDaSessao;
    }

    public boolean isLogado() {
        return (usuarioDaSessao != null);
    }

    public boolean perfilAdmin() {
        return (this.isLogado() && this.getUsuarioDaSessao().isAdmin());
    }

    public String logar() {
        FacesContext context = FacesContext.getCurrentInstance();
        List<Usuario> listaDeUsuarios = usuarioMB.getListaDeUsuarios();
        for (Usuario usuarioDaLista : listaDeUsuarios) {
            if (usuarioDaLista.validaLogin(login, senha)) {
                usuarioDaSessao = usuarioDaLista;
                if (usuarioDaLista.isAdmin()) {
                    return ("/paginas/admin/home?faces-redirect=true");
                } else {
                    return ("/paginas/usuario/home?faces-redirect=true");
                }
            }
        }
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login inválido!", "Usuário ou Senha inválidos");
        context.addMessage("idMsn", message);
        return ("/paginas/login");
    }

    public String logoff() {
        usuarioDaSessao = null;
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return ("/paginas/login?faces=redirect=true");
    }
}
