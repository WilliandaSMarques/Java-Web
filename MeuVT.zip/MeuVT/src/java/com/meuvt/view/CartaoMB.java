package com.meuvt.view;

import com.meuvt.model.Cartao;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;

import javax.inject.Named;

/**
 * @author willian
 * @since 10.09.2016
 */
@Named(value = "CartaoMB")
@ApplicationScoped
public class CartaoMB implements Serializable {

    private List<Cartao> listaDeCartoes;
    private Cartao cartaoSelecionado;

    public CartaoMB() {
        cartaoSelecionado = new Cartao();
        listaDeCartoes = new ArrayList<>();
        listaDeCartoes.add(new Cartao(1L));
    }

    /**
     * @return the listaDeCartoes
     */
    public List<Cartao> getListaDeCartoes() {
        return listaDeCartoes;
    }

    /**
     * @param listaDeCartoes the listaDeCartoes to set
     */
    public void setListaDeCartoes(List<Cartao> listaDeCartoes) {
        this.listaDeCartoes = listaDeCartoes;
    }

    /**
     * @return the cartaoSelecionado
     */
    public Cartao getCartaoSelecionado() {
        return cartaoSelecionado;
    }

    /**
     * @param cartaoSelecionado the cartaoSelecionado to set
     */
    public void setCartaoSelecionado(Cartao cartaoSelecionado) {
        this.cartaoSelecionado = cartaoSelecionado;
    }

    /**
     *
     * @return o formulario de cadastro de cartao para cadastra-lo
     */
    public String novoCartao() {
        cartaoSelecionado = new Cartao();
        return ("/paginas/admin/cadastraCartao?faces-redirect=true");
    }

    /**
     *
     * @return cadastra o cartao, após o preenchimento do formulario
     */
    public String cadastraCartao() {
        listaDeCartoes.add(cartaoSelecionado);
        return ("/paginas/admin/inicioCartao?faces-redirect=true");
    }

    /**
     *
     * @param c
     * @return edita todas as informações de um cartao já cadastrado no sistema
     */
    public String editaCartao(Cartao c) {
        cartaoSelecionado = c;
        return ("/paginas/admin/formularioEditaCartao?faces-redirect=true");
    }

    /**
     *
     * @return atualiza todas as informações de um cartao, após uma edição
     */
    public String atualizaCartao() {
        return ("/paginas/admin/inicioCartao?faces-redirect=true");
    }

    /**
     *
     * @param c - exclui um usuario cadastrado no sistema
     */
    public void excluiCartao(Cartao c) {
        listaDeCartoes.remove(c);
    }
}
