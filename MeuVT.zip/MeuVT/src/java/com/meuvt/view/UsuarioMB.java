package com.meuvt.view;

import com.meuvt.model.Usuario;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

/**
 * @author willian
 * @since 07.09.2016
 */
@Named(value = "UsuarioMB")
@ApplicationScoped
public class UsuarioMB implements Serializable {

    private List<Usuario> listaDeUsuarios;
    private Usuario usuarioSelecionado;

    public UsuarioMB() {
        usuarioSelecionado = new Usuario();
        listaDeUsuarios = new ArrayList<>();
        listaDeUsuarios.add(new Usuario("admin", "admin"));

    }

    /**
     * @return the listaDeUsuarios
     */
    public List<Usuario> getListaDeUsuarios() {
        return listaDeUsuarios;
    }

    /**
     * @param listaDeUsuarios the listaDeUsuarios to set
     */
    public void setListaDeUsuarios(List<Usuario> listaDeUsuarios) {
        this.listaDeUsuarios = listaDeUsuarios;
    }

    /**
     * @return the usuarioSelecionado
     */
    public Usuario getUsuarioSelecionado() {
        return usuarioSelecionado;
    }

    /**
     * @param usuarioSelecionado the usuarioSelecionado to set
     */
    public void setUsuarioSelecionado(Usuario usuarioSelecionado) {
        this.usuarioSelecionado = usuarioSelecionado;
    }

    /**
     *
     * @return o formulario de cadastro de usuario para cadastra-lo
     */
    public String novoUsuario() {
        usuarioSelecionado = new Usuario();
        return ("/paginas/admin/cadastraUsuario?faces-redirect=true");
    }

    /**
     *
     * @return cadastra o usuario, após o preenchimento do formulario
     */
    public String cadastrarUsuario() {
        listaDeUsuarios.add(usuarioSelecionado);
        return ("/paginas/admin/inicioUsuario?faces-redirect=true");
    }

    /**
     *
     * @param u
     * @return edita todas as informações de um usuario já cadastrado no sistema
     */
    public String editaUsuario(Usuario u) {
        usuarioSelecionado = u;
        return ("/paginas/admin/formularioEditaUsuario?faces-redirect=true");
    }

    /**
     *
     * @return atualiza todas as informações de um usuario, após uma edição
     */
    public String atualizaUsuario() {
        return ("/paginas/admin/inicioUsuario?faces-redirect=true");
    }

    /**
     *
     * @param u - exclui um usuario cadastrado no sistema
     */
    public void excluiUsuario(Usuario u) {
        listaDeUsuarios.remove(u);
    }
}
