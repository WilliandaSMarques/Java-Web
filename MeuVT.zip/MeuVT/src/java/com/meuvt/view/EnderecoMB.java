package com.meuvt.view;

import com.meuvt.model.Endereco;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

/**
 * @author willian
 * @since 09.09.2016
 */
@Named(value = "EnderecoMB")
@ApplicationScoped
public class EnderecoMB implements Serializable {

    private List<Endereco> listaDeEnderecos;
    private Endereco enderecoSelecioando;

    public EnderecoMB() {
        enderecoSelecioando = new Endereco();
        listaDeEnderecos = new ArrayList<>();
        listaDeEnderecos.add(new Endereco(1L));
    }

    /**
     * @return the listaDeEnderecos
     */
    public List<Endereco> getListaDeEnderecos() {
        return listaDeEnderecos;
    }

    /**
     * @param listaDeEnderecos the listaDeEnderecos to set
     */
    public void setListaDeEnderecos(List<Endereco> listaDeEnderecos) {
        this.listaDeEnderecos = listaDeEnderecos;
    }

    /**
     * @return the enderecoSelecioando
     */
    public Endereco getEnderecoSelecioando() {
        return enderecoSelecioando;
    }

    /**
     * @param enderecoSelecioando the enderecoSelecioando to set
     */
    public void setEnderecoSelecioando(Endereco enderecoSelecioando) {
        this.enderecoSelecioando = enderecoSelecioando;
    }

    /**
     *
     * @return o formulario de cadastro de endereco para cadastra-lo
     */
    public String novoEndereco() {
        enderecoSelecioando = new Endereco();
        return ("/paginas/admin/cadastraEndereco?faces-redirect=true");
    }

    /**
     *
     * @return cadastra o endereco, após o preenchimento do formulario
     */
    public String cadastraEndereco() {
        listaDeEnderecos.add(enderecoSelecioando);
        return ("/paginas/admin/inicioEndereco?faces-redirect=true");
    }

    /**
     *
     * @param e
     * @return edita todas as informações de um endereco já cadastrado no
     * sistema
     */
    public String editaEndereco(Endereco e) {
        enderecoSelecioando = e;
        return ("/paginas/admin/formularioEditaEndereco?faces-redirect=true");
    }

    /**
     *
     * @return atualiza todas as informações de um endereco, após uma edição
     */
    public String atualizaEndereco() {
        return ("/paginas/admin/inicioEndereco?faces-redirect=true");
    }

    /**
     *
     * @param e - exclui um endereco cadastrado no sistema
     */
    public void excluiEndereco(Endereco e) {
        listaDeEnderecos.remove(e);
    }
}
