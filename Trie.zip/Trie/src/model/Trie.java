package model;

import java.util.HashMap;
import java.util.Map;

public class Trie {

	private class No {
		Map<Character, No> comeco;
		boolean verificaPalavra;

		public No() {
			comeco = new HashMap<>();
			verificaPalavra = false;
		}
	}

	private final No raiz;

	public Trie() {
		raiz = new No();
	}

	public void inserePalavra(String palavra) {
		No no = raiz;
		for (int i = 0; i < palavra.length(); i++) {
			char c = palavra.charAt(i);
			No novo = no.comeco.get(c);
			if (novo == null) {
				novo = new No();
				no.comeco.put(c, novo);
			}
			no = novo;
		}
		no.verificaPalavra = true;
	}

	public void inserePalavraRecursivamente(String palavra) {
		inserePalavraRecursivamente(raiz, palavra, 0);
	}

	private void inserePalavraRecursivamente(No no, String palavra, int index) {
		if (index == palavra.length()) {
			no.verificaPalavra = true;
			return;
		}
		char c = palavra.charAt(index);
		No novo = no.comeco.get(c);

		if (novo == null) {
			novo = new No();
			no.comeco.put(c, novo);
		}
		inserePalavraRecursivamente(novo, palavra, index + 1);
	}

	public boolean pesquisePalavra(String palavra) {
		No no = raiz;
		for (int i = 0; i < palavra.length(); i++) {
			char c = palavra.charAt(i);
			No novo = no.comeco.get(c);

			if (novo == null) {
				return false;
			}
			no = novo;
		}
		return no.verificaPalavra;
	}

	public boolean pesquisePalavraRecursivamente(String palavra) {
		return pesquisePalavraRecursivamente(raiz, palavra, 0);
	}

	private boolean pesquisePalavraRecursivamente(No no, String palavra, int index) {
		if (index == palavra.length()) {
			return no.verificaPalavra;
		}
		char c = palavra.charAt(index);
		No novo = no.comeco.get(c);

		if (novo == null) {
			return false;
		}
		return pesquisePalavraRecursivamente(novo, palavra, index + 1);
	}

	public void deletePalavra(String palavra) {
		deletePalavra(raiz, palavra, 0);
	}

	private boolean deletePalavra(No no, String palavra, int index) {
		if(index == palavra.length()){
			if(!no.verificaPalavra){
				return false;
			}
			no.verificaPalavra = false;
			return no.comeco.size() == 0;
		}
		char c = palavra.charAt(index);
		No novo = no.comeco.get(c);
		if(novo == null){
			return false;
		}
		boolean noAtual = deletePalavra(novo, palavra, index + 1);
		
		if(noAtual){
			no.comeco.remove(c);
			
			return no.comeco.size() == 0;
		}
		return false;		
	}
}