package teste;

import model.Trie;

public class TestaTrie {

	public static void main(String[] args) {
		
		Trie trie = new Trie();
		
		trie.inserePalavra("a");
		trie.inserePalavra("b");
		trie.inserePalavra("c");
		trie.inserePalavra("d");
		trie.inserePalavra("e");
		trie.inserePalavra("f");
		trie.inserePalavra("g");
		trie.inserePalavra("h");
		trie.inserePalavra("i");
		trie.inserePalavra("j");
		trie.inserePalavra("k");
		trie.inserePalavra("l");
		trie.inserePalavra("m");
		trie.inserePalavra("n");
		trie.inserePalavra("o");
		trie.inserePalavra("p");
		trie.inserePalavra("q");
		trie.inserePalavra("r");
		trie.inserePalavra("s");
		trie.inserePalavra("t");
		trie.inserePalavra("u");
		trie.inserePalavra("v");
		trie.inserePalavra("x");
		trie.inserePalavra("y");
		trie.inserePalavra("z");}}