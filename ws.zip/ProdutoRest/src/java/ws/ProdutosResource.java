package ws;

import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import model.Produto;
import repositorio.RepositorioProdutos;

/**
 * REST Web Service
 *
 * @author 631420137
 */
@Path("produtos")
public class ProdutosResource {

    @Context
    private UriInfo context;
    @EJB
    RepositorioProdutos repositorioProdutos;

    /**
     * Creates a new instance of ProdutosResource
     */
    public ProdutosResource() {
    }

    /**
     * Retrieves representation of an instance of ws.ProdutosResource
     *
     * @return an instance of model.Produto
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public List<Produto> getProdutos() {
        return repositorioProdutos.getListaProdutos();
    }

    /**
     * PUT method for updating or creating an instance of ProdutosResource
     *
     * @param produto representation for the resource
     * @return String
     */
    @POST
    @Consumes(MediaType.APPLICATION_XML)
    @Produces("text/plain")
    public String addProduto(Produto produto) {
        repositorioProdutos.adicionar(produto);
        return "Ok";
    }
}
