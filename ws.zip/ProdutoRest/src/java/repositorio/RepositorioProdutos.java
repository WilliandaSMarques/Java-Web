/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repositorio;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import model.Produto;

/**
 *
 * @author 631420137
 */
@Stateless
public class RepositorioProdutos {

    private List<Produto> listaProdutos;

    public RepositorioProdutos() {
        listaProdutos = new ArrayList<>();
        listaProdutos.add(new Produto("Refrigerante", 3.90));
        listaProdutos.add(new Produto("Bolinho-de-Queijo",4.90));
        
    }
    
    

    /**
     * @return the listaProdutos
     */
    public List<Produto> getListaProdutos() {
        return listaProdutos;
    }

    /**
     * @param listaProdutos the listaProdutos to set
     */
    public void setListaProdutos(List<Produto> listaProdutos) {
        this.listaProdutos = listaProdutos;
    }

    public void adicionar(Produto produto) {
        listaProdutos.add(produto);
    }
    
    
}
