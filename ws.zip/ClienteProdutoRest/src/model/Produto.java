package model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 631420137
 */
@XmlRootElement
public class Produto implements Serializable {

    private String nome;
    private Double preco;

    public Produto() {
    }

    /**
     *
     * @param nome
     * @param produto
     */
    public Produto(String nome, Double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the produto
     */
    public Double getPreco() {
        return preco;
    }

    /**
     * @param preco the produto to set
     */
    public void setPreco(Double preco) {
        this.preco = preco;
    }

}
